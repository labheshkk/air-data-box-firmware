# Test Plan

## Unit Tests
- Moving average convergence
- Low-pass step response
- Airspeed calculation against known differential pressures
- Altitude calculation against known static pressures
- Scheduler rollover behavior

## Hardware Tests
- Sensor initialization
- Sensor read timing
- Static-pressure cross-check
- FDCAN electrical validation
- DroneCAN node-status broadcast
- Air-data publication rate
- Bus-off recovery
- Power-cycle recovery

## Client Acceptance Parameters Still Required
- Exact sensor interfaces and pin map
- Sampling rates
- Pressure/airspeed/altitude accuracy targets
- CAN bitrate
- DroneCAN node-ID strategy
- DSDL message set
