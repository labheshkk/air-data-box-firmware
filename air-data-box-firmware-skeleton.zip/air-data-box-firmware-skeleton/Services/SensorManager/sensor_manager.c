#include "Services/SensorManager/sensor_manager.h"
#include "Drivers/Honeywell/honeywell.h"
#include "Drivers/BMP581/bmp581.h"
#include "Drivers/MS5611/ms5611.h"
#include <string.h>

static SensorManagerData_t s_data;

Status_t SensorManager_Init(void)
{
    memset(&s_data, 0, sizeof(s_data));

    HoneywellConfig_t honeywell_cfg = {
        .transport = HONEYWELL_TRANSPORT_SPI,
        .i2c_address = 0U,
        .spi_bus_id = 1U,
        .spi_cs_id = 0U
    };

    BMP581Config_t bmp_cfg = {
        .i2c_address = 0x47U
    };

    MS5611Config_t ms_cfg = {
        .spi_bus_id = 2U,
        .spi_cs_id = 0U
    };

    (void)Honeywell_Init(&honeywell_cfg);
    (void)BMP581_Init(&bmp_cfg);
    (void)MS5611_Init(&ms_cfg);

    return STATUS_OK;
}

void SensorManager_Run(void)
{
    (void)Honeywell_Read(&s_data.differential);
    (void)BMP581_Read(&s_data.static_bmp);
    (void)MS5611_Read(&s_data.static_ms);
}

const SensorManagerData_t *SensorManager_GetData(void)
{
    return &s_data;
}
