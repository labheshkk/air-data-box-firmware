#ifndef SENSOR_MANAGER_H
#define SENSOR_MANAGER_H

#include "Common/status.h"
#include "Drivers/Sensor/sensor_types.h"

typedef struct
{
    SensorSample_t differential;
    SensorSample_t static_bmp;
    SensorSample_t static_ms;
} SensorManagerData_t;

Status_t SensorManager_Init(void);
void SensorManager_Run(void);
const SensorManagerData_t *SensorManager_GetData(void);

#endif
