#ifndef AIRDATA_H
#define AIRDATA_H

#include <stdint.h>
#include "Common/status.h"

typedef struct
{
    float dynamic_pressure_pa;
    float static_pressure_pa;
    float airspeed_mps;
    float altitude_m;
    float temperature_c;
    uint32_t timestamp_ms;
    uint8_t valid;
} AirDataOutput_t;

Status_t AirData_Init(void);
Status_t AirData_Update(void);
const AirDataOutput_t *AirData_GetOutput(void);

#endif
