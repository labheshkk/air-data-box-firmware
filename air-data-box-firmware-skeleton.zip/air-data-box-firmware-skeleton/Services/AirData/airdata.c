#include "Services/AirData/airdata.h"
#include "Services/SensorManager/sensor_manager.h"
#include "Services/Filters/filters.h"
#include "Config/platform_config.h"
#include "Platform/platform_port.h"
#include <math.h>
#include <string.h>

static AirDataOutput_t s_output;
static MovingAverage_t s_dp_avg;
static MovingAverage_t s_static_avg;
static LowPassFilter_t s_dp_lpf;
static LowPassFilter_t s_static_lpf;

Status_t AirData_Init(void)
{
    memset(&s_output, 0, sizeof(s_output));
    MovingAverage_Init(&s_dp_avg);
    MovingAverage_Init(&s_static_avg);
    LowPass_Init(&s_dp_lpf, AIRDATA_LPF_ALPHA);
    LowPass_Init(&s_static_lpf, AIRDATA_LPF_ALPHA);
    return STATUS_OK;
}

Status_t AirData_Update(void)
{
    const SensorManagerData_t *s = SensorManager_GetData();

    if ((s == 0) ||
        (s->differential.valid == 0U) ||
        ((s->static_bmp.valid == 0U) && (s->static_ms.valid == 0U)))
    {
        s_output.valid = 0U;
        return STATUS_NOT_READY;
    }

    float static_pressure;

    if ((s->static_bmp.valid != 0U) && (s->static_ms.valid != 0U))
        static_pressure = 0.5f * (s->static_bmp.pressure_pa + s->static_ms.pressure_pa);
    else if (s->static_bmp.valid != 0U)
        static_pressure = s->static_bmp.pressure_pa;
    else
        static_pressure = s->static_ms.pressure_pa;

    float dp = s->differential.pressure_pa;

    dp = MovingAverage_Update(&s_dp_avg, dp);
    dp = LowPass_Update(&s_dp_lpf, dp);

    static_pressure = MovingAverage_Update(&s_static_avg, static_pressure);
    static_pressure = LowPass_Update(&s_static_lpf, static_pressure);

    if (dp < 0.0f) dp = 0.0f;
    if (static_pressure <= 0.0f)
    {
        s_output.valid = 0U;
        return STATUS_INVALID;
    }

    s_output.dynamic_pressure_pa = dp;
    s_output.static_pressure_pa = static_pressure;
    s_output.airspeed_mps = sqrtf((2.0f * dp) / AIRDATA_SEA_LEVEL_DENSITY_KGM3);
    s_output.altitude_m =
        44330.0f *
        (1.0f - powf(static_pressure / AIRDATA_SEA_LEVEL_PRESSURE_PA, 0.19029495f));

    if ((s->static_bmp.valid != 0U) && (s->static_ms.valid != 0U))
        s_output.temperature_c = 0.5f * (s->static_bmp.temperature_c + s->static_ms.temperature_c);
    else if (s->static_bmp.valid != 0U)
        s_output.temperature_c = s->static_bmp.temperature_c;
    else
        s_output.temperature_c = s->static_ms.temperature_c;

    s_output.timestamp_ms = Platform_GetTickMs();
    s_output.valid = 1U;
    return STATUS_OK;
}

const AirDataOutput_t *AirData_GetOutput(void)
{
    return &s_output;
}
