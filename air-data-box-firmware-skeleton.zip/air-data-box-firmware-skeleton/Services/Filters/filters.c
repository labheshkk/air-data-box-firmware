#include "Services/Filters/filters.h"
#include <string.h>

void MovingAverage_Init(MovingAverage_t *f)
{
    if (f == 0) return;
    memset(f, 0, sizeof(*f));
}

float MovingAverage_Update(MovingAverage_t *f, float input)
{
    if (f == 0) return input;

    if (f->count < AIRDATA_MOVING_AVG_WINDOW)
    {
        f->samples[f->index] = input;
        f->sum += input;
        f->count++;
    }
    else
    {
        f->sum -= f->samples[f->index];
        f->samples[f->index] = input;
        f->sum += input;
    }

    f->index = (uint8_t)((f->index + 1U) % AIRDATA_MOVING_AVG_WINDOW);
    return f->sum / (float)f->count;
}

void LowPass_Init(LowPassFilter_t *f, float alpha)
{
    if (f == 0) return;
    f->alpha = alpha;
    f->state = 0.0f;
    f->initialized = 0U;
}

float LowPass_Update(LowPassFilter_t *f, float input)
{
    if (f == 0) return input;

    if (f->initialized == 0U)
    {
        f->state = input;
        f->initialized = 1U;
        return input;
    }

    f->state = f->state + f->alpha * (input - f->state);
    return f->state;
}
