#ifndef FILTERS_H
#define FILTERS_H

#include <stdint.h>
#include "Config/platform_config.h"

typedef struct
{
    float samples[AIRDATA_MOVING_AVG_WINDOW];
    uint8_t index;
    uint8_t count;
    float sum;
} MovingAverage_t;

typedef struct
{
    float alpha;
    float state;
    uint8_t initialized;
} LowPassFilter_t;

void MovingAverage_Init(MovingAverage_t *f);
float MovingAverage_Update(MovingAverage_t *f, float input);

void LowPass_Init(LowPassFilter_t *f, float alpha);
float LowPass_Update(LowPassFilter_t *f, float input);

#endif
