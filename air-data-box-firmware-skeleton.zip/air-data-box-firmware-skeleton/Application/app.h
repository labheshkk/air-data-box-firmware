#ifndef APP_H
#define APP_H

#include "Common/status.h"

Status_t APP_Init(void);
void APP_Run(void);

#endif
