/*
 * Keep CubeMX-generated main.c and call:
 *
 * HAL_Init();
 * SystemClock_Config();
 * MX_GPIO_Init();
 * MX_I2C1_Init();
 * MX_SPI1_Init();
 * MX_SPI2_Init();
 * MX_FDCAN1_Init();
 *
 * if (APP_Init() != STATUS_OK)
 *     Error_Handler();
 *
 * while (1)
 *     APP_Run();
 */
