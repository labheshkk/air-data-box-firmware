#include "Application/app.h"
#include "Application/scheduler.h"
#include "Services/SensorManager/sensor_manager.h"
#include "Services/AirData/airdata.h"
#include "Communication/DroneCAN/dronecan_if.h"

Status_t APP_Init(void)
{
    DroneCANConfig_t dronecan_cfg = {
        .node_id = 42U,
        .bitrate = 1000000U
    };

    if (SensorManager_Init() != STATUS_OK) return STATUS_ERROR;
    if (AirData_Init() != STATUS_OK) return STATUS_ERROR;
    if (DroneCAN_Init(&dronecan_cfg) != STATUS_OK) return STATUS_ERROR;

    Scheduler_Init();
    return STATUS_OK;
}

void APP_Run(void)
{
    Scheduler_Run();
}
