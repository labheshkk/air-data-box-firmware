#include "Application/scheduler.h"
#include "Config/platform_config.h"
#include "Platform/platform_port.h"
#include "Services/SensorManager/sensor_manager.h"
#include "Services/AirData/airdata.h"
#include "Communication/DroneCAN/dronecan_if.h"

typedef struct
{
    uint32_t sensor_ms;
    uint32_t airdata_ms;
    uint32_t dronecan_ms;
    uint32_t health_ms;
} SchedulerState_t;

static SchedulerState_t s_last;

static uint8_t elapsed(uint32_t now, uint32_t *last, uint32_t period)
{
    if ((uint32_t)(now - *last) >= period)
    {
        *last = now;
        return 1U;
    }
    return 0U;
}

void Scheduler_Init(void)
{
    uint32_t now = Platform_GetTickMs();
    s_last.sensor_ms = now;
    s_last.airdata_ms = now;
    s_last.dronecan_ms = now;
    s_last.health_ms = now;
}

void Scheduler_Run(void)
{
    uint32_t now = Platform_GetTickMs();

    if (elapsed(now, &s_last.sensor_ms, TASK_SENSOR_PERIOD_MS))
        SensorManager_Run();

    if (elapsed(now, &s_last.airdata_ms, TASK_AIRDATA_PERIOD_MS))
        (void)AirData_Update();

    if (elapsed(now, &s_last.dronecan_ms, TASK_DRONECAN_PERIOD_MS))
    {
        DroneCAN_Run();
        (void)DroneCAN_PublishAirData();
    }

    if (elapsed(now, &s_last.health_ms, TASK_HEALTH_PERIOD_MS))
        (void)DroneCAN_PublishNodeStatus();
}
