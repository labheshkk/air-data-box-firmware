# Engineering Assumptions

## Confirmed
- MCU: STM32H755ZIT6
- Network protocol: DroneCAN

## Provisional
- Cortex-M7 hosts the initial application.
- Bare-metal periodic scheduler.
- BMP581 on I2C.
- MS5611 on SPI.
- Honeywell transport abstracted until interface is confirmed.
- DroneCAN bitrate: 1 Mbit/s.
- DroneCAN node ID: 42.
- Air-data publication period: 20 ms.

These placeholders must be replaced by the actual schematic, pin map,
sensor interface configuration, and DroneCAN network specification.
